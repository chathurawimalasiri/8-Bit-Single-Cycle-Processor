# 8bit_DADDA_Multiplier
DADDA multiplier  uses a selection of full and half adders to sum the partial products in stages until two numbers are left
